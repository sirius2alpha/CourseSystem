package com.example.project.mapper;

import com.example.project.entity.CoursePlan;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author ge
 * @since 2023-10-20
 */
public interface CoursePlanMapper extends BaseMapper<CoursePlan> {

}
