package com.example.project.service;

import com.example.project.entity.Teachers;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author ge
 * @since 2023-10-20
 */
public interface TeachersService extends IService<Teachers> {

}
